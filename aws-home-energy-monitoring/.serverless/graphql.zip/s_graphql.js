
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'adyanf',
  applicationName: 'uas-home-energy-monitor',
  appUid: 'QgcRd3bcFBCCSVXvH7',
  orgUid: '49110803-2afe-48fb-85aa-8d23b0575a82',
  deploymentUid: 'd990a9b2-41f8-44e7-97d1-4ea063aa7950',
  serviceName: 'uas-home-energy-monitor',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.1.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'uas-home-energy-monitor-prod-graphql', timeout: 6 };

try {
  const userHandler = require('./functions/graphql/graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}